<div class="modal fade " id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">เข้าสู่ระบบ</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form method="post" action="login.php">
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">ชื่อผู้ใช้:</label>
                        <input type="text" class="form-control"  name="username" id="username" required>
                    </div>
                    <label for="recipient-name" class="col-form-label">รหัสผ่าน:</label>
                    <input type="password" class="form-control"  name="password" id="password" required>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success" id="ok">ตกลง</button>
                        <button type="reset" class="btn btn-danger">ยกเลิก</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>








