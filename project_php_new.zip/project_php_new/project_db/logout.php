<?PHP 
	session_start();
//logout.php
	session_destroy();
?>

<META HTTP-EQUIV="Refresh" CONTENT="0;URL=index.php">