<footer class="footer_show_hide">
		<div class="container">
			<div class="row row-pb-md">
				<div class="col-md-12 colorlib-widget">
					<h4 style="color:red;">ผู้พัฒนา</h4>
					<marquee><p style="color:blue;"> นาย กิดาการ อินทปัญญา ติดต่อโทร 083-110-1923</p></marquee>
				</div>
				</div>
			</div>
		</div>
	</footer>