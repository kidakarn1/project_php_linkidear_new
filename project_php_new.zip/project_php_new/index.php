<!DOCTYPE HTML>
<html>
    <head>
        <!-- Facebook and Twitter integration -->
        <meta property="og:title" content=""/>
        <meta property="og:image" content=""/>
        <meta property="og:url" content=""/>
        <meta property="og:site_name" content=""/>
        <meta property="og:description" content=""/>
        <meta name="twitter:title" content="" />
        <meta name="twitter:image" content="" />
        <meta name="twitter:url" content="" />
        <meta name="twitter:card" content="" />
        <?php include ("menu.php"); ?>
    </head>
    <body>
        <aside id="colorlib-hero" class="js-fullheight">
            <div class="flexslider js-fullheight">
                <ul class="slides">
                    <li style="background-image: url(images/img_bg_1.jpg);">
                        <div class="overlay-gradient"></div>
                        <div class="container">
                            <div class="row">
                                <div class="col-md-10 col-md-offset-1 text-center js-fullheight slider-text">
                                    <div class="slider-text-inner">
                                        <div class="show_hide_index">
                                            <img src="icon_image/logo_shop.png" width="50">
                                            <h1>สร้างสรรค์  เน้นคุณภาพ </h1>
                                            <h1>ส่งมอบทันเวลา พัฒนาอย่างต่อเนื่อง</h1>
                                            <h1><font color="#ffff00">สร้างสรรค์  ไม่ยึดติด</h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>	   	
                </ul>
            </div>
        </aside>	

        <?php
        include("footer.php");
        ?>
    </body>
</html>


